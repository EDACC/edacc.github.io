#ifndef __miniunz_h__
#define __miniunz_h__

int decompress(const char* zipfile, const char* dirname, void *md5res);

#endif
