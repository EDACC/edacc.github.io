#ifndef __message_thread_h__
#define __message_thread_h__

void start_message_thread(int client_id);
void stop_message_thread();
void process_messages();
#endif
