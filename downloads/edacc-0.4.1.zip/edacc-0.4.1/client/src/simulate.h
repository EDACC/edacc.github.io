/*
 * simulate.h
 *
 *  Created on: 26.06.2011
 *      Author: simon
 */

#ifndef SIMULATE_H_
#define SIMULATE_H_

#include "datastructures.h"
void initialize_simulation(Methods &methods);
void simulate_exit_client();

#endif /* SIMULATE_H_ */
